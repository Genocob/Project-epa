import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Code2,
  Copy,
  Download,
  Eye,
  FilePlus2,
  FolderOpen,
  GripVertical,
  Layers3,
  LayoutTemplate,
  Maximize2,
  Minus,
  MousePointer2,
  PanelLeft,
  PanelRight,
  Plus,
  Redo2,
  Save,
  Settings2,
  Sparkles,
  Trash2,
  Type,
  Undo2,
  X,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import { toast, Toaster } from "sonner";
import {
  defaultElement,
  elementIcon,
  elementLabel,
  generateCss,
  generateHtml,
  projectFromTemplate,
  createEmptyProject,
  templates,
  type EditorElement,
  type ElementType,
  type Page,
  type Project,
} from "@/lib/editor";
import "./index.css";

const STORAGE_KEY = "layoutlab-project-v1";
const CANVAS_WIDTH = 760;
const CANVAS_HEIGHT = 560;

const palette = [
  { type: "heading" as ElementType, label: "Título", hint: "Hierarquia" },
  { type: "paragraph" as ElementType, label: "Parágrafo", hint: "Conteúdo" },
  { type: "image" as ElementType, label: "Imagem", hint: "Visual" },
  { type: "button" as ElementType, label: "Botão / CTA", hint: "Ação" },
  { type: "link" as ElementType, label: "Link", hint: "Navegação" },
  { type: "field" as ElementType, label: "Campo de texto", hint: "Entrada" },
  { type: "card" as ElementType, label: "Card", hint: "Agrupar" },
  { type: "section" as ElementType, label: "Seção", hint: "Estrutura" },
  { type: "footer" as ElementType, label: "Rodapé", hint: "Encerramento" },
];

type View = "menu" | "editor" | "code";

type HistoryState = { past: Project[]; future: Project[] };

const clone = <T,>(data: T): T => JSON.parse(JSON.stringify(data));

function App() {
  const [view, setView] = useState<View>("menu");
  const [project, setProject] = useState<Project>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : projectFromTemplate(templates[0]);
    } catch {
      return projectFromTemplate(templates[0]);
    }
  });
  const [activePageId, setActivePageId] = useState(project.pages[0]?.id ?? "");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [zoom, setZoom] = useState(0.82);
  const [history, setHistory] = useState<HistoryState>({ past: [], future: [] });
  const [generated, setGenerated] = useState(() => generateHtml(project));
  const [showPreview, setShowPreview] = useState(false);
  const [dragType, setDragType] = useState<ElementType | null>(null);
  const [dragId, setDragId] = useState<string | null>(null);

  const activePage = project.pages.find((page) => page.id === activePageId) ?? project.pages[0];
  const selectedElement = activePage?.elements.find((element) => element.id === selectedId) ?? null;

  useEffect(() => {
    if (!project.pages.some((page) => page.id === activePageId)) setActivePageId(project.pages[0]?.id ?? "");
  }, [activePageId, project.pages]);

  useEffect(() => {
    setGenerated(generateHtml(project));
  }, [project]);

  const updateProject = (updater: (draft: Project) => Project, recordHistory = true) => {
    setProject((current) => {
      const next = updater(clone(current));
      next.updatedAt = new Date().toISOString();
      if (recordHistory) setHistory((h) => ({ past: [...h.past.slice(-29), current], future: [] }));
      return next;
    });
  };

  const updateActivePage = (updater: (page: Page) => Page, recordHistory = true) => {
    updateProject((draft) => {
      const index = draft.pages.findIndex((page) => page.id === (activePage?.id ?? activePageId));
      if (index >= 0) draft.pages[index] = updater(draft.pages[index]);
      return draft;
    }, recordHistory);
  };

  const saveProject = () => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(project));
    toast.success("Projeto salvo no navegador", { description: "Você poderá continuar de onde parou." });
  };

  const loadSaved = () => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (!saved) return toast.info("Ainda não há um projeto salvo");
      const parsed: Project = JSON.parse(saved);
      setProject(parsed);
      setActivePageId(parsed.pages[0]?.id ?? "");
      setSelectedId(null);
      setView("editor");
      toast.success("Projeto carregado");
    } catch {
      toast.error("Não foi possível carregar o projeto");
    }
  };

  const startProject = (next: Project) => {
    setProject(next);
    setActivePageId(next.pages[0]?.id ?? "");
    setSelectedId(null);
    setHistory({ past: [], future: [] });
    setView("editor");
    toast.success("Editor pronto", { description: "Agora personalize a composição visual." });
  };

  const undo = () => {
    setHistory((current) => {
      const previous = current.past[current.past.length - 1];
      if (!previous) return current;
      setProject(previous);
      return { past: current.past.slice(0, -1), future: [project, ...current.future] };
    });
  };

  const redo = () => {
    setHistory((current) => {
      const next = current.future[0];
      if (!next) return current;
      setProject(next);
      return { past: [...current.past, project], future: current.future.slice(1) };
    });
  };

  const addElement = (type: ElementType, point?: { x: number; y: number }) => {
    if (!activePage) return;
    const position = point ?? { x: 72 + (activePage.elements.length % 3) * 28, y: 72 + (activePage.elements.length % 4) * 78 };
    const element = defaultElement(type, Math.min(Math.max(position.x, 18), CANVAS_WIDTH - 220), Math.min(Math.max(position.y, 18), CANVAS_HEIGHT - 80));
    updateActivePage((page) => ({ ...page, elements: [...page.elements, element] }));
    setSelectedId(element.id);
  };

  const updateSelected = (changes: Partial<EditorElement>) => {
    if (!selectedId) return;
    updateActivePage((page) => ({ ...page, elements: page.elements.map((element) => element.id === selectedId ? { ...element, ...changes } : element) }));
  };

  const removeSelected = () => {
    if (!selectedId) return;
    updateActivePage((page) => ({ ...page, elements: page.elements.filter((element) => element.id !== selectedId) }));
    setSelectedId(null);
    toast.success("Elemento removido");
  };

  const clearPage = () => {
    if (!activePage || !window.confirm("Limpar todos os elementos desta página?")) return;
    updateActivePage((page) => ({ ...page, elements: [] }));
    setSelectedId(null);
  };

  const addPage = () => {
    if (project.pages.length >= 3) return toast.info("O MVP permite até 3 páginas por projeto");
    const newPage: Page = { id: `page-${Date.now()}`, name: `Página ${project.pages.length + 1}`, elements: [] };
    updateProject((draft) => ({ ...draft, pages: [...draft.pages, newPage] }));
    setActivePageId(newPage.id);
    setSelectedId(null);
  };

  const renamePage = (pageId: string) => {
    const page = project.pages.find((item) => item.id === pageId);
    const name = window.prompt("Nome da página", page?.name ?? "Página");
    if (!name?.trim()) return;
    updateProject((draft) => ({ ...draft, pages: draft.pages.map((item) => item.id === pageId ? { ...item, name: name.trim() } : item) }));
  };

  const deletePage = (pageId: string) => {
    if (project.pages.length === 1) return toast.info("O projeto precisa ter ao menos uma página");
    if (!window.confirm("Excluir esta página?")) return;
    const remaining = project.pages.filter((page) => page.id !== pageId);
    updateProject((draft) => ({ ...draft, pages: remaining }));
    setActivePageId(remaining[0].id);
    setSelectedId(null);
  };

  const handleCanvasDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    const rect = event.currentTarget.getBoundingClientRect();
    const x = (event.clientX - rect.left) / zoom;
    const y = (event.clientY - rect.top) / zoom;
    if (dragType) addElement(dragType, { x: x - 12, y: y - 12 });
    if (dragId) updateSelectedPosition(dragId, { x: x - 18, y: y - 18 });
    setDragType(null);
    setDragId(null);
  };

  const updateSelectedPosition = (id: string, position: { x: number; y: number }) => {
    updateActivePage((page) => ({ ...page, elements: page.elements.map((element) => element.id === id ? { ...element, x: Math.max(12, Math.min(CANVAS_WIDTH - element.width - 12, position.x)), y: Math.max(12, Math.min(CANVAS_HEIGHT - element.height - 12, position.y)) } : element) }));
  };

  const duplicateSelected = () => {
    if (!selectedElement) return;
    const duplicate = { ...clone(selectedElement), id: `el-${Date.now()}`, x: selectedElement.x + 18, y: selectedElement.y + 18 };
    updateActivePage((page) => ({ ...page, elements: [...page.elements, duplicate] }));
    setSelectedId(duplicate.id);
  };

  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText(generated);
      toast.success("Código copiado");
    } catch {
      toast.error("Não foi possível copiar automaticamente");
    }
  };

  const downloadCode = () => {
    const blob = new Blob([generated], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${project.name.toLowerCase().replace(/[^a-z0-9]+/g, "-") || "layoutlab"}.html`;
    anchor.click();
    URL.revokeObjectURL(url);
    toast.success("Arquivo HTML baixado");
  };

  return (
    <>
      <Toaster position="bottom-right" richColors />
      {view === "menu" && <MenuView project={project} onStart={startProject} onLoad={loadSaved} onOpenEditor={() => setView("editor")} onOpenCode={() => setView("code")} />}
      {view === "editor" && (
        <EditorView
          project={project}
          activePage={activePage}
          activePageId={activePageId}
          selectedElement={selectedElement}
          selectedId={selectedId}
          zoom={zoom}
          history={history}
          dragType={dragType}
          onNavigate={setView}
          onSelect={setSelectedId}
          onPageChange={(id) => { setActivePageId(id); setSelectedId(null); }}
          onAddElement={addElement}
          onDrop={handleCanvasDrop}
          onDragType={setDragType}
          onDragId={setDragId}
          onUpdateSelected={updateSelected}
          onRemove={removeSelected}
          onClear={clearPage}
          onSave={saveProject}
          onAddPage={addPage}
          onRenamePage={renamePage}
          onDeletePage={deletePage}
          onUndo={undo}
          onRedo={redo}
          onZoom={(value) => setZoom(Math.min(1.15, Math.max(0.58, value)))}
          onGenerate={() => { setGenerated(generateHtml(project)); setView("code"); }}
          onDuplicate={duplicateSelected}
          showPreview={showPreview}
          onPreview={() => setShowPreview(true)}
          onClosePreview={() => setShowPreview(false)}
        />
      )}
      {view === "code" && <CodeView project={project} generated={generated} onNavigate={setView} onCopy={copyCode} onDownload={downloadCode} onGenerate={() => setGenerated(generateHtml(project))} />}
    </>
  );
}

function Brand({ compact = false }: { compact?: boolean }) {
  return <div className={`brand-lockup ${compact ? "is-compact" : ""}`}><div className="brand-mark"><Sparkles size={15} strokeWidth={2.5} /></div><div><div className="brand-name">layout<span>lab</span></div>{!compact && <div className="brand-subtitle">design que vira estrutura</div>}</div></div>;
}

function MenuView({ project, onStart, onLoad, onOpenEditor, onOpenCode }: { project: Project; onStart: (project: Project) => void; onLoad: () => void; onOpenEditor: () => void; onOpenCode: () => void }) {
  const saved = Boolean(localStorage.getItem(STORAGE_KEY));
  return <div className="app-shell menu-shell">
    <header className="site-header"><Brand /><nav className="top-nav"><button className="nav-link is-active">Menu</button><button className="nav-link" onClick={onOpenEditor}>Criação do layout <ArrowRight size={14} /></button><button className="nav-link" onClick={onOpenCode}>Gerador de código <Code2 size={14} /></button></nav><div className="header-meta"><span className="status-dot" /> execução local</div></header>
    <main className="menu-content">
      <section className="intro-grid">
        <div className="intro-copy"><div className="kicker"><span className="kicker-line" /> laboratório visual para iniciantes</div><h1>Ideias visuais que<br /><em>ganham estrutura.</em></h1><p>Monte páginas web com componentes reais, explore princípios de Design Digital e veja como suas escolhas se traduzem em HTML e CSS.</p><div className="intro-actions"><button className="primary-btn" onClick={() => onStart(createEmptyProject())}><Plus size={17} /> começar do zero</button>{saved && <button className="secondary-btn" onClick={onLoad}><FolderOpen size={16} /> abrir salvo</button>}</div><div className="intro-note"><span className="note-icon"><MousePointer2 size={14} /></span><span>Feito para aprender criando · sem cadastro, sem conta, sem complicação</span></div></div>
        <div className="intro-visual"><div className="visual-orbit orbit-one" /><div className="visual-orbit orbit-two" /><div className="visual-card visual-card-back"><div className="mini-bar" /><div className="mini-lines"><i /><i /><i /></div></div><div className="visual-card visual-card-front"><div className="mini-card-head"><span className="mini-dot pink" /><span className="mini-dot yellow" /><span className="mini-dot mint" /><span className="mini-label">canvas</span></div><div className="mini-canvas"><div className="mini-title" /><div className="mini-subtitle" /><div className="mini-block block-a" /><div className="mini-block block-b" /><div className="mini-button" /></div><div className="mini-footer"><span /> <span /> <span /></div></div><div className="floating-tag tag-one"><LayoutTemplate size={14} /> 5 estruturas</div><div className="floating-tag tag-two"><Code2 size={14} /> código real</div></div>
      </section>
      <section className="templates-section"><div className="section-heading"><div><div className="eyebrow">01 / ponto de partida</div><h2>Escolha uma estrutura para explorar</h2></div><span className="template-count">{templates.length} modelos · componentes editáveis</span></div><div className="template-grid">{templates.map((template) => <TemplateCard key={template.id} template={template} onClick={() => onStart(projectFromTemplate(template))} />)}</div></section>
      <section className="principles-strip"><div className="principle"><span>01</span><div><strong>Componha</strong><p>Escolha uma base e organize ideias.</p></div></div><div className="principle"><span>02</span><div><strong>Experimente</strong><p>Altere cores, ritmo e hierarquia.</p></div></div><div className="principle"><span>03</span><div><strong>Entenda</strong><p>Veja o design virar estrutura.</p></div></div></section>
    </main>
    <footer className="site-footer"><span>LayoutLab / Etec Sales Gomes</span><span>um projeto de Design Digital + desenvolvimento web</span></footer>
  </div>;
}

function TemplateCard({ template, onClick }: { template: (typeof templates)[number]; onClick: () => void }) {
  return <button className="template-card" onClick={onClick} style={{ "--template-accent": template.accent } as React.CSSProperties}><div className={`template-preview preview-${template.layout}`}><div className="preview-window"><div className="preview-top"><span /><span /><span /></div><div className="preview-body"><div className="preview-shape shape-one" /><div className="preview-shape shape-two" /><div className="preview-shape shape-three" /><div className="preview-shape shape-four" /></div></div><div className="template-hover"><span>abrir modelo <ArrowRight size={14} /></span><small>{template.purpose}</small></div></div><div className="template-info"><div><span className="template-eyebrow">{template.eyebrow}</span><h3>{template.name}</h3></div><span className="template-arrow"><ArrowUpRight size={15} /></span></div><p>{template.description}</p></button>;
}

function EditorView(props: {
  project: Project;
  activePage?: Page;
  activePageId: string;
  selectedElement: EditorElement | null;
  selectedId: string | null;
  zoom: number;
  history: HistoryState;
  dragType: ElementType | null;
  onNavigate: (view: View) => void;
  onSelect: (id: string | null) => void;
  onPageChange: (id: string) => void;
  onAddElement: (type: ElementType) => void;
  onDrop: (event: React.DragEvent<HTMLDivElement>) => void;
  onDragType: (type: ElementType | null) => void;
  onDragId: (id: string | null) => void;
  onUpdateSelected: (changes: Partial<EditorElement>) => void;
  onRemove: () => void;
  onClear: () => void;
  onSave: () => void;
  onAddPage: () => void;
  onRenamePage: (id: string) => void;
  onDeletePage: (id: string) => void;
  onUndo: () => void;
  onRedo: () => void;
  onZoom: (value: number) => void;
  onGenerate: () => void;
  onDuplicate: () => void;
  showPreview: boolean;
  onPreview: () => void;
  onClosePreview: () => void;
}) {
  const { project, activePage, selectedElement, selectedId, zoom } = props;
  return <div className="editor-shell"><header className="editor-header"><div className="editor-header-left"><button className="icon-btn" onClick={() => props.onNavigate("menu")} title="Voltar ao menu"><ArrowLeft size={17} /></button><Brand compact /><span className="header-divider" /><div className="project-title"><span className="saved-pulse" />{project.name}<ChevronDown size={14} /></div></div><div className="editor-header-center"><button className="editor-nav is-active" onClick={() => props.onNavigate("editor")}><LayoutTemplate size={15} /> criação do layout</button><button className="editor-nav" onClick={() => props.onNavigate("code")}><Code2 size={15} /> gerador de código</button></div><div className="editor-header-actions"><button className="icon-btn" onClick={props.onUndo} disabled={!props.history.past.length} title="Desfazer"><Undo2 size={16} /></button><button className="icon-btn" onClick={props.onRedo} disabled={!props.history.future.length} title="Refazer"><Redo2 size={16} /></button><button className="ghost-action" onClick={props.onPreview}><Eye size={15} /> visualizar</button><button className="save-btn" onClick={props.onSave}><Save size={15} /> salvar</button><button className="code-btn" onClick={props.onGenerate}><Code2 size={15} /> gerar código</button></div></header><div className="editor-layout"><aside className="component-panel"><div className="panel-label">biblioteca</div><div className="panel-heading"><div><h2>Elementos</h2><p>arraste para o canvas</p></div><button className="tiny-icon"><Settings2 size={15} /></button></div><div className="component-list">{palette.map((item) => <button key={item.type} className="component-item" draggable onDragStart={() => props.onDragType(item.type)} onDragEnd={() => props.onDragType(null)} onClick={() => props.onAddElement(item.type)}><span className="component-icon">{elementIcon(item.type)}</span><span className="component-copy"><strong>{item.label}</strong><small>{item.hint}</small></span><GripVertical size={14} className="grip" /></button>)}</div><div className="panel-tip"><Sparkles size={14} /><span>Comece com uma seção. Ela ajuda a manter a composição organizada.</span></div></aside><main className="workspace"><div className="workspace-toolbar"><div className="toolbar-context"><span className="context-pill"><Layers3 size={14} /> {activePage?.name ?? "Página"}</span><span className="toolbar-muted">{activePage?.elements.length ?? 0} elementos</span></div><div className="toolbar-actions"><button className="tool-btn" onClick={props.onClear}><Trash2 size={14} /> limpar página</button><span className="toolbar-divider" /><button className="zoom-btn" onClick={() => props.onZoom(zoom - 0.1)}><ZoomOut size={15} /></button><span className="zoom-value">{Math.round(zoom * 100)}%</span><button className="zoom-btn" onClick={() => props.onZoom(zoom + 0.1)}><ZoomIn size={15} /></button></div></div><div className="canvas-stage"><div className="canvas-ruler ruler-top"><span>0</span><span>200</span><span>400</span><span>600</span><span>760</span></div><div className="canvas-ruler ruler-left"><span>0</span><span>140</span><span>280</span><span>420</span><span>560</span></div><div className="canvas-zoom-wrap" style={{ transform: `scale(${zoom})` }}><div className="design-canvas" onDragOver={(event) => event.preventDefault()} onDrop={props.onDrop} onClick={(event) => { if (event.target === event.currentTarget) props.onSelect(null); }}><div className="canvas-grid" />{activePage?.elements.map((element) => <CanvasElement key={element.id} element={element} selected={selectedId === element.id} onSelect={() => props.onSelect(element.id)} onDragStart={() => props.onDragId(element.id)} onDragEnd={() => props.onDragId(null)} />)}{!activePage?.elements.length && <div className="canvas-empty"><div className="empty-orb"><Plus size={20} /></div><h3>Seu canvas está pronto</h3><p>Arraste um elemento da biblioteca ou comece com uma seção.</p></div>}</div></div></div><PageTabs pages={project.pages} activePageId={props.activePageId} onPageChange={props.onPageChange} onAddPage={props.onAddPage} onRenamePage={props.onRenamePage} onDeletePage={props.onDeletePage} /></main><aside className="properties-panel"><div className="panel-label">inspetor</div>{selectedElement ? <PropertiesPanel element={selectedElement} pages={project.pages} onChange={props.onUpdateSelected} onRemove={props.onRemove} onDuplicate={props.onDuplicate} /> : <div className="inspector-empty"><div className="inspector-icon"><MousePointer2 size={18} /></div><h3>Selecione um elemento</h3><p>Escolha algo no canvas para editar texto, cor, tamanho e alinhamento.</p><div className="shortcut-list"><span><kbd>click</kbd> selecionar</span><span><kbd>drag</kbd> mover</span><span><kbd>↗</kbd> redimensionar pelo painel</span></div></div>}<div className="inspector-footer"><span>LayoutLab v0.1</span><span>salvo localmente</span></div></aside></div>{props.showPreview && <PreviewModal project={project} onClose={props.onClosePreview} />}</div>;
}

function CanvasElement({ element, selected, onSelect, onDragStart, onDragEnd }: { element: EditorElement; selected: boolean; onSelect: () => void; onDragStart: () => void; onDragEnd: () => void }) {
  const style: React.CSSProperties = { left: element.x, top: element.y, width: element.width, height: element.height, color: element.color, background: element.background === "transparent" ? undefined : element.background, fontSize: element.fontSize, borderRadius: element.radius, textAlign: element.align };
  return <div className={`canvas-element element-${element.type} ${selected ? "is-selected" : ""}`} style={style} draggable onDragStart={(event) => { event.stopPropagation(); onDragStart(); }} onDragEnd={onDragEnd} onClick={(event) => { event.stopPropagation(); onSelect(); }}><span className="element-content">{element.type === "image" ? <><span className="image-glyph">▧</span>{element.content}</> : element.type === "field" ? <><span className="field-label">Aa</span>{element.content}</> : element.content}</span>{selected && <><span className="selection-label">{elementLabel(element.type)}</span><span className="resize-dot" /></>}</div>;
}

function PageTabs({ pages, activePageId, onPageChange, onAddPage, onRenamePage, onDeletePage }: { pages: Page[]; activePageId: string; onPageChange: (id: string) => void; onAddPage: () => void; onRenamePage: (id: string) => void; onDeletePage: (id: string) => void }) {
  return <div className="pages-dock"><div className="pages-title"><span className="panel-label">páginas</span><button className="add-page-btn" onClick={onAddPage}><Plus size={14} /> nova página</button></div><div className="page-tabs">{pages.map((page, index) => <div className={`page-tab ${activePageId === page.id ? "is-active" : ""}`} key={page.id}><button onClick={() => onPageChange(page.id)}><span className="page-number">0{index + 1}</span>{page.name}</button><div className="page-tab-actions"><button onClick={() => onRenamePage(page.id)}><Settings2 size={12} /></button>{pages.length > 1 && <button onClick={() => onDeletePage(page.id)}><X size={12} /></button>}</div></div>)}</div></div>;
}

function PropertiesPanel({ element, pages, onChange, onRemove, onDuplicate }: { element: EditorElement; pages: Page[]; onChange: (changes: Partial<EditorElement>) => void; onRemove: () => void; onDuplicate: () => void }) {
  const textChange = (key: keyof EditorElement, value: string | number) => onChange({ [key]: value } as Partial<EditorElement>);
  return <div className="properties-content"><div className="selected-object"><span className="selected-object-icon">{elementIcon(element.type)}</span><div><span>selecionado</span><strong>{elementLabel(element.type)}</strong></div><button onClick={onRemove} title="Excluir"><Trash2 size={14} /></button></div><div className="property-group"><span className="property-group-title">conteúdo</span>{["heading", "paragraph", "button", "link", "card", "section", "footer", "image", "field"].includes(element.type) && <label className="field-label-control"><span>{element.type === "image" ? "descrição" : "texto"}</span><textarea value={element.content} onChange={(event) => textChange("content", event.target.value)} rows={element.type === "paragraph" ? 3 : 2} /></label>}{(element.type === "button" || element.type === "link") && <label className="field-label-control"><span>destino externo</span><input value={element.href ?? ""} onChange={(event) => textChange("href", event.target.value)} placeholder="https://..." /></label>}{(element.type === "button" || element.type === "link") && pages.length > 1 && <label className="field-label-control"><span>página de destino</span><select value={element.targetPageId ?? ""} onChange={(event) => textChange("targetPageId", event.target.value)}><option value="">nenhuma</option>{pages.map((page) => <option key={page.id} value={page.id}>{page.name}</option>)}</select></label>}</div><div className="property-group"><span className="property-group-title">aparência</span><div className="control-row"><label className="field-label-control"><span>cor</span><div className="color-input"><input type="color" value={element.color === "transparent" ? "#233047" : element.color} onChange={(event) => textChange("color", event.target.value)} /><input value={element.color} onChange={(event) => textChange("color", event.target.value)} /></div></label><label className="field-label-control"><span>fundo</span><div className="color-input"><input type="color" value={element.background === "transparent" ? "#ffffff" : element.background} onChange={(event) => textChange("background", event.target.value)} /><input value={element.background} onChange={(event) => textChange("background", event.target.value)} /></div></label></div><div className="control-row"><label className="field-label-control"><span>tamanho</span><input type="number" min="10" max="64" value={element.fontSize} onChange={(event) => textChange("fontSize", Number(event.target.value))} /></label><label className="field-label-control"><span>raio</span><input type="number" min="0" max="40" value={element.radius} onChange={(event) => textChange("radius", Number(event.target.value))} /></label></div><div className="align-control"><span>alinhamento</span><div className="align-buttons">{(["left", "center", "right"] as const).map((align) => <button key={align} className={element.align === align ? "is-active" : ""} onClick={() => onChange({ align })}>{align === "left" ? "≡" : align === "center" ? "≡" : "≡"}</button>)}</div></div></div><div className="property-group"><span className="property-group-title">dimensões & posição</span><div className="dimension-grid"><label className="field-label-control"><span>X</span><input type="number" value={Math.round(element.x)} onChange={(event) => textChange("x", Number(event.target.value))} /></label><label className="field-label-control"><span>Y</span><input type="number" value={Math.round(element.y)} onChange={(event) => textChange("y", Number(event.target.value))} /></label><label className="field-label-control"><span>largura</span><input type="number" min="60" max="740" value={Math.round(element.width)} onChange={(event) => textChange("width", Number(event.target.value))} /></label><label className="field-label-control"><span>altura</span><input type="number" min="24" max="540" value={Math.round(element.height)} onChange={(event) => textChange("height", Number(event.target.value))} /></label></div></div><button className="duplicate-btn" onClick={onDuplicate}><Copy size={14} /> duplicar elemento</button></div>;
}

function PreviewModal({ project, onClose }: { project: Project; onClose: () => void }) {
  const [pageId, setPageId] = useState(project.pages[0]?.id ?? "");
  const page = project.pages.find((item) => item.id === pageId) ?? project.pages[0];
  return <div className="preview-overlay"><div className="preview-modal"><div className="preview-modal-head"><div><span className="eyebrow">modo de visualização</span><h2>{project.name}</h2></div><button className="icon-btn" onClick={onClose}><X size={18} /></button></div><div className="preview-page-tabs">{project.pages.map((item) => <button key={item.id} className={item.id === page?.id ? "is-active" : ""} onClick={() => setPageId(item.id)}>{item.name}</button>)}</div><div className="preview-frame"><div className="preview-canvas">{page?.elements.map((element) => <CanvasElement key={element.id} element={element} selected={false} onSelect={() => undefined} onDragStart={() => undefined} onDragEnd={() => undefined} />)}</div></div><div className="preview-modal-foot"><span><Eye size={14} /> sem controles de edição</span><button className="secondary-btn" onClick={onClose}>voltar ao editor</button></div></div></div>;
}

function CodeView({ project, generated, onNavigate, onCopy, onDownload, onGenerate }: { project: Project; generated: string; onNavigate: (view: View) => void; onCopy: () => void; onDownload: () => void; onGenerate: () => void }) {
  const lines = generated.split("\n");
  return <div className="code-shell"><header className="editor-header"><div className="editor-header-left"><button className="icon-btn" onClick={() => onNavigate("menu")}><ArrowLeft size={17} /></button><Brand compact /><span className="header-divider" /><div className="project-title"><span className="saved-pulse" />{project.name}</div></div><div className="editor-header-center"><button className="editor-nav" onClick={() => onNavigate("editor")}><LayoutTemplate size={15} /> criação do layout</button><button className="editor-nav is-active" onClick={() => onNavigate("code")}><Code2 size={15} /> gerador de código</button></div><div className="editor-header-actions"><button className="ghost-action" onClick={() => onNavigate("editor")}><ArrowLeft size={15} /> voltar ao editor</button><button className="save-btn" onClick={onCopy}><Copy size={15} /> copiar código</button><button className="code-btn" onClick={onDownload}><Download size={15} /> baixar HTML</button></div></header><main className="code-content"><div className="code-intro"><div><div className="kicker"><span className="kicker-line" /> gerador baseado no estado do projeto</div><h1>Seu layout,<br /><em>em código legível.</em></h1><p>O resultado abaixo foi gerado a partir dos componentes, páginas e propriedades que você criou no editor.</p></div><button className="primary-btn" onClick={onGenerate}><Code2 size={17} /> atualizar código</button></div><div className="code-layout"><section className="code-panel"><div className="code-panel-head"><div className="code-tabs"><span className="code-tab is-active"><span className="file-dot html-dot" />index.html</span><span className="code-tab"><span className="file-dot css-dot" />styles.css</span></div><span className="code-panel-meta">{lines.length} linhas</span></div><div className="code-scroll"><pre>{lines.map((line, index) => <div className="code-line" key={`${index}-${line}`}><span className="line-number">{String(index + 1).padStart(3, "0")}</span><code>{highlightCode(line)}</code></div>)}</pre></div></section><aside className="code-side"><div className="code-side-card"><div className="side-card-icon"><Sparkles size={17} /></div><span className="eyebrow">o que foi traduzido</span><h3>Do canvas para a web</h3><ul><li><span>01</span> {project.pages.length} página(s) estruturada(s)</li><li><span>02</span> {project.pages.reduce((sum, page) => sum + page.elements.length, 0)} componente(s) convertido(s)</li><li><span>03</span> estilos responsivos incluídos</li><li><span>04</span> navegação preservada</li></ul></div><div className="code-side-note"><Code2 size={16} /><p>O código é simples, estudável e pode servir como ponto de partida para um projeto real.</p></div></aside></div></main></div>;
}

function highlightCode(line: string) {
  const parts = line.split(/(<[^>]+>)/g);
  return parts.map((part, index) => part.startsWith("<") ? <span className="syntax-tag" key={index}>{part}</span> : <span key={index}>{part}</span>);
}

export default App;
