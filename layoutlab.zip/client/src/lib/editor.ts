export type ElementType =
  | "section"
  | "heading"
  | "paragraph"
  | "image"
  | "button"
  | "link"
  | "field"
  | "card"
  | "footer";

export type Page = {
  id: string;
  name: string;
  elements: EditorElement[];
};

export type EditorElement = {
  id: string;
  type: ElementType;
  content: string;
  x: number;
  y: number;
  width: number;
  height: number;
  color: string;
  background: string;
  fontSize: number;
  radius: number;
  align: "left" | "center" | "right";
  href?: string;
  targetPageId?: string;
  children?: EditorElement[];
};

export type Project = {
  id: string;
  name: string;
  templateId: string;
  updatedAt: string;
  pages: Page[];
};

export type Template = {
  id: string;
  name: string;
  eyebrow: string;
  description: string;
  purpose: string;
  accent: string;
  layout: "single" | "split" | "grid" | "hero" | "reading";
  pages: Page[];
};

const uid = (prefix: string) => `${prefix}-${Math.random().toString(36).slice(2, 9)}`;

const base = (overrides: Partial<EditorElement>): EditorElement => ({
  id: uid("el"),
  type: "paragraph",
  content: "Novo elemento",
  x: 80,
  y: 80,
  width: 260,
  height: 72,
  color: "#233047",
  background: "transparent",
  fontSize: 16,
  radius: 16,
  align: "left",
  ...overrides,
});

const page = (name: string, elements: EditorElement[]): Page => ({ id: uid("page"), name, elements });

export const templates: Template[] = [
  {
    id: "single",
    name: "Coluna única",
    eyebrow: "Foco & clareza",
    description: "Uma composição vertical para apresentar uma ideia com hierarquia visual.",
    purpose: "Ideal para páginas pessoais, projetos escolares e apresentações diretas.",
    accent: "#7c5cff",
    layout: "single",
    pages: [
      page("Início", [
        base({ type: "section", content: "Seção principal", x: 28, y: 28, width: 704, height: 128, background: "#efeaff", radius: 24 }),
        base({ type: "heading", content: "Sua ideia começa aqui", x: 72, y: 54, width: 420, height: 56, fontSize: 34, color: "#35265f" }),
        base({ type: "paragraph", content: "Organize uma mensagem clara e transforme intenção em uma página visual.", x: 72, y: 112, width: 430, height: 42, fontSize: 14, color: "#685c83" }),
        base({ type: "card", content: "Aprenda fazendo", x: 74, y: 202, width: 248, height: 148, background: "#ffffff", color: "#233047" }),
        base({ type: "card", content: "Visualize antes do código", x: 344, y: 202, width: 248, height: 148, background: "#ffffff", color: "#233047" }),
        base({ type: "button", content: "Começar agora", x: 72, y: 394, width: 164, height: 48, background: "#7c5cff", color: "#ffffff", fontSize: 14, radius: 14 }),
        base({ type: "footer", content: "LayoutLab · Design que vira estrutura", x: 70, y: 474, width: 500, height: 24, color: "#8a91a4", fontSize: 12 }),
      ]),
    ],
  },
  {
    id: "split",
    name: "Duas colunas",
    eyebrow: "Contraste & ritmo",
    description: "Duas áreas de atenção para equilibrar texto, imagem e ação.",
    purpose: "Funciona bem para portfólios, páginas de evento e apresentação de projetos.",
    accent: "#17b890",
    layout: "split",
    pages: [
      page("Início", [
        base({ type: "section", content: "Área visual", x: 28, y: 28, width: 326, height: 420, background: "#dff7ee", radius: 24 }),
        base({ type: "image", content: "Imagem / ilustração", x: 70, y: 150, width: 242, height: 150, background: "#b5ead7", color: "#227b63", align: "center", radius: 20 }),
        base({ type: "heading", content: "Um lado explica. O outro convida.", x: 396, y: 84, width: 270, height: 100, fontSize: 30, color: "#153e35" }),
        base({ type: "paragraph", content: "Use o contraste entre colunas para guiar o olhar e criar uma narrativa visual.", x: 396, y: 210, width: 258, height: 68, color: "#52736d" }),
        base({ type: "link", content: "Conhecer o projeto →", x: 396, y: 330, width: 190, height: 34, color: "#0b9b79", fontSize: 15 }),
        base({ type: "footer", content: "Projeto escolar · 2026", x: 396, y: 444, width: 180, height: 24, color: "#8a91a4", fontSize: 12 }),
      ]),
    ],
  },
  {
    id: "grid",
    name: "Grid de cards",
    eyebrow: "Organização modular",
    description: "Blocos independentes para comparar, explicar ou apresentar opções.",
    purpose: "Ideal para serviços, projetos, recursos e portfólios com várias partes.",
    accent: "#ff8b5c",
    layout: "grid",
    pages: [
      page("Início", [
        base({ type: "heading", content: "Tudo em seu lugar", x: 52, y: 44, width: 430, height: 54, fontSize: 32, color: "#5b2b1b" }),
        base({ type: "paragraph", content: "Cards ajudam o usuário a entender grupos de informação de forma rápida.", x: 54, y: 102, width: 430, height: 40, color: "#85675b" }),
        base({ type: "card", content: "01  Ideia", x: 54, y: 186, width: 194, height: 142, background: "#fff3ec", color: "#6f3d2a" }),
        base({ type: "card", content: "02  Estrutura", x: 274, y: 186, width: 194, height: 142, background: "#ffe9db", color: "#6f3d2a" }),
        base({ type: "card", content: "03  Código", x: 494, y: 186, width: 194, height: 142, background: "#ffd8c4", color: "#6f3d2a" }),
        base({ type: "button", content: "Ver processo", x: 54, y: 382, width: 150, height: 46, background: "#ee7042", color: "#ffffff", radius: 14 }),
      ]),
    ],
  },
  {
    id: "z",
    name: "Layout em Z",
    eyebrow: "Fluxo de leitura",
    description: "Uma jornada visual em quatro pontos de atenção, como um caminho em Z.",
    purpose: "Bom para landing pages educativas, campanhas e chamadas com começo, meio e fim.",
    accent: "#e7b94f",
    layout: "hero",
    pages: [
      page("Início", [
        base({ type: "heading", content: "O olhar também navega", x: 52, y: 48, width: 330, height: 52, fontSize: 32, color: "#4d3c15" }),
        base({ type: "link", content: "Explorar estrutura →", x: 552, y: 64, width: 150, height: 28, color: "#9b741d", fontSize: 13, align: "right" }),
        base({ type: "image", content: "Ponto de atenção", x: 52, y: 148, width: 228, height: 132, background: "#f8e9b9", color: "#85651d", align: "center", radius: 18 }),
        base({ type: "paragraph", content: "O padrão em Z cria um caminho natural entre elementos importantes.", x: 452, y: 158, width: 242, height: 64, color: "#7d6b43", align: "right" }),
        base({ type: "card", content: "Mensagem principal", x: 278, y: 316, width: 230, height: 112, background: "#fff7dd", color: "#5e4a18" }),
        base({ type: "button", content: "Continuar", x: 552, y: 366, width: 130, height: 46, background: "#d59e26", color: "#ffffff", radius: 14 }),
      ]),
    ],
  },
  {
    id: "f",
    name: "Layout em F",
    eyebrow: "Leitura escaneável",
    description: "Uma estrutura que prioriza títulos e blocos alinhados para leitura rápida.",
    purpose: "Indicado para conteúdos, guias, notícias e páginas com bastante informação.",
    accent: "#e66c8c",
    layout: "reading",
    pages: [
      page("Início", [
        base({ type: "heading", content: "Leia por camadas", x: 58, y: 42, width: 460, height: 52, fontSize: 32, color: "#69243d" }),
        base({ type: "paragraph", content: "A hierarquia visual ajuda o usuário a encontrar o que procura.", x: 58, y: 104, width: 460, height: 36, color: "#8d6471" }),
        base({ type: "section", content: "Conteúdo em destaque", x: 58, y: 174, width: 568, height: 64, background: "#fbe4eb", radius: 14 }),
        base({ type: "section", content: "Resumo do conteúdo", x: 58, y: 264, width: 478, height: 52, background: "#fff2f5", radius: 12 }),
        base({ type: "section", content: "Ponto de ação", x: 58, y: 342, width: 406, height: 52, background: "#fff2f5", radius: 12 }),
        base({ type: "button", content: "Acessar conteúdo", x: 58, y: 430, width: 172, height: 46, background: "#d65378", color: "#ffffff", radius: 14 }),
      ]),
    ],
  },
];

export const createEmptyProject = (): Project => ({
  id: uid("project"),
  name: "Meu primeiro layout",
  templateId: "empty",
  updatedAt: new Date().toISOString(),
  pages: [page("Início", [])],
});

export const projectFromTemplate = (template: Template): Project => ({
  id: uid("project"),
  name: `${template.name} · Meu projeto`,
  templateId: template.id,
  updatedAt: new Date().toISOString(),
  pages: template.pages.map((item) => ({
    ...item,
    id: uid("page"),
    elements: item.elements.map((element) => ({ ...element, id: uid("el"), children: element.children?.map((child) => ({ ...child, id: uid("el") })) })),
  })),
});

export const elementLabel = (type: ElementType) => {
  const labels: Record<ElementType, string> = {
    section: "Seção",
    heading: "Título",
    paragraph: "Parágrafo",
    image: "Imagem",
    button: "Botão / CTA",
    link: "Link",
    field: "Campo de texto",
    card: "Card",
    footer: "Rodapé",
  };
  return labels[type];
};

export const elementIcon = (type: ElementType) => {
  const icons: Record<ElementType, string> = {
    section: "▦",
    heading: "T",
    paragraph: "¶",
    image: "▧",
    button: "↗",
    link: "⌁",
    field: "▤",
    card: "▣",
    footer: "⌄",
  };
  return icons[type];
};

export const defaultElement = (type: ElementType, x = 80, y = 80): EditorElement => {
  const defaults: Record<ElementType, Partial<EditorElement>> = {
    section: { content: "Nova seção", width: 620, height: 100, background: "#f1f4f9", radius: 20 },
    heading: { content: "Novo título", width: 310, height: 52, fontSize: 30, color: "#233047" },
    paragraph: { content: "Escreva uma mensagem para o seu público.", width: 300, height: 64, fontSize: 15, color: "#607089" },
    image: { content: "Sua imagem", width: 220, height: 140, background: "#dce6f3", color: "#526681", align: "center", radius: 18 },
    button: { content: "Ação principal", width: 150, height: 48, background: "#7c5cff", color: "#ffffff", fontSize: 14, radius: 14 },
    link: { content: "Link de navegação →", width: 180, height: 32, fontSize: 14, color: "#7c5cff" },
    field: { content: "Seu nome", width: 250, height: 48, background: "#ffffff", color: "#7a8498", fontSize: 14, radius: 12 },
    card: { content: "Novo card", width: 230, height: 130, background: "#ffffff", color: "#233047", radius: 18 },
    footer: { content: "Rodapé da página", width: 330, height: 30, fontSize: 12, color: "#8a91a4" },
  };
  return base({ type, x, y, ...defaults[type] });
};

const escapeHtml = (value: string) => value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

const cssColor = (color: string) => color || "transparent";

const renderExportElement = (element: EditorElement, page: Page, pages: Page[]): string => {
  const style = `left:${element.x}px;top:${element.y}px;width:${element.width}px;height:${element.height}px;color:${cssColor(element.color)};background:${cssColor(element.background)};font-size:${element.fontSize}px;border-radius:${element.radius}px;text-align:${element.align};`;
  const linkTarget = element.targetPageId ? `data-target="${escapeHtml(element.targetPageId)}"` : element.href ? `href="${escapeHtml(element.href)}" target="_blank" rel="noreferrer"` : "";
  const content = escapeHtml(element.content);
  const children = element.children?.length ? `<div class="ll-card-children">${element.children.map((child) => renderExportElement(child, page, pages)).join("")}</div>` : "";
  const tagByType: Record<ElementType, string> = { section: "section", heading: "h1", paragraph: "p", image: "div", button: "button", link: "a", field: "input", card: "article", footer: "footer" };
  const tag = tagByType[element.type];
  if (element.type === "image") return `<${tag} class="ll-element ll-${element.type}" style="${style}">${content}</${tag}>`;
  if (element.type === "field") return `<${tag} class="ll-element ll-${element.type}" style="${style}" placeholder="${content}" aria-label="${content}" />`;
  if (element.type === "link" || element.type === "button") return `<${tag} class="ll-element ll-${element.type}" style="${style}" ${linkTarget}>${content}</${tag}>`;
  return `<${tag} class="ll-element ll-${element.type}" style="${style}">${content}${children}</${tag}>`;
};

export const generateHtml = (project: Project) => {
  const firstPage = project.pages[0];
  const pageMarkup = project.pages.map((pageItem, index) => `<main class="ll-page ${index === 0 ? "is-active" : ""}" data-page="${pageItem.id}" aria-label="${escapeHtml(pageItem.name)}">${pageItem.elements.map((element) => renderExportElement(element, pageItem, project.pages)).join("")}</main>`).join("\n");
  const nav = project.pages.length > 1 ? `<nav class="ll-pages-nav">${project.pages.map((pageItem, index) => `<button data-target="${pageItem.id}" class="${index === 0 ? "is-active" : ""}">${escapeHtml(pageItem.name)}</button>`).join("")}</nav>` : "";
  return `<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${escapeHtml(project.name)}</title>
  <style>
${generateCss()}
  </style>
</head>
<body>
  <div class="ll-app">
    <header class="ll-header"><span class="ll-brand">${escapeHtml(project.name)}</span>${nav}</header>
    ${pageMarkup || `<main class="ll-page is-active" data-page="${firstPage?.id ?? "home"}"></main>`}
  </div>
  <script>
    document.querySelectorAll('[data-target]').forEach(function (item) {
      item.addEventListener('click', function () {
        var target = item.getAttribute('data-target');
        document.querySelectorAll('.ll-page').forEach(function (page) { page.classList.toggle('is-active', page.getAttribute('data-page') === target); });
        document.querySelectorAll('.ll-pages-nav button').forEach(function (button) { button.classList.toggle('is-active', button.getAttribute('data-target') === target); });
      });
    });
  </script>
</body>
</html>`;
};

export const generateCss = () => `
* { box-sizing: border-box; }
body { margin: 0; color: #233047; background: #f6f8fc; font-family: Inter, ui-sans-serif, system-ui, sans-serif; }
.ll-app { width: min(100%, 960px); min-height: 100vh; margin: 0 auto; padding: 24px; }
.ll-header { display: flex; align-items: center; justify-content: space-between; gap: 20px; padding: 16px 0 28px; }
.ll-brand { font-weight: 800; letter-spacing: -0.03em; }
.ll-pages-nav { display: flex; gap: 8px; flex-wrap: wrap; }
.ll-pages-nav button { border: 0; border-radius: 999px; padding: 8px 12px; background: #e8ecf4; color: #52617b; cursor: pointer; }
.ll-pages-nav button.is-active { background: #7c5cff; color: white; }
.ll-page { display: none; position: relative; width: 100%; min-height: 560px; overflow: hidden; border-radius: 28px; background: white; box-shadow: 0 20px 80px rgba(35, 48, 71, .12); }
.ll-page.is-active { display: block; }
.ll-element { position: absolute; margin: 0; padding: 12px; overflow: hidden; border: 0; line-height: 1.35; }
.ll-heading { font-weight: 800; letter-spacing: -0.04em; }
.ll-paragraph { line-height: 1.55; }
.ll-image { display: grid; place-items: center; font-weight: 700; }
.ll-button { cursor: pointer; font-weight: 800; }
.ll-link { display: block; text-decoration: none; font-weight: 800; }
.ll-field { border: 1px solid #dce3ef; outline: none; }
.ll-card { box-shadow: 0 14px 30px rgba(35, 48, 71, .08); font-weight: 800; }
.ll-section { opacity: .78; }
.ll-footer { font-weight: 700; }
.ll-card-children { position: absolute; inset: 12px; }
@media (max-width: 680px) { .ll-app { padding: 12px; } .ll-page { min-height: 680px; transform-origin: top left; } .ll-header { align-items: flex-start; flex-direction: column; } }
`;
